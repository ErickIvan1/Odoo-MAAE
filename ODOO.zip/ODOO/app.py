# app.py
from werkzeug.security import check_password_hash
from werkzeug.security import generate_password_hash
from flask import Flask, render_template, request, redirect, session
from models import db, User, Question, Answer

app = Flask(__name__)
app.secret_key = 'clave_secreta'
import os
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'db.sqlite3')

db.init_app(app)

@app.route('/')
def index():
    if 'user_id' in session:
        questions = Question.query.all()
        return render_template('questions.html', questions=questions)
    return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()

        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            return redirect('/')
        else:
            error = 'Usuario o contraseña incorrectos'
            return render_template('login.html', error=error)

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Verificar si el usuario ya existe
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            error = 'El nombre de usuario ya está en uso.'
            return render_template('register.html', error=error)

        # Hashear la contraseña antes de guardar
        hashed_password = generate_password_hash(password)

        # Crear y guardar el nuevo usuario
        new_user = User(username=username, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        return redirect('/login')

    return render_template('register.html')
@app.route('/add_question', methods=['POST'])
def add_question():
    if 'user_id' not in session:
        return redirect('/login')

    text = request.form['text']
    user_id = session['user_id']

    if text:
        new_q = Question(text=text, user_id=user_id)
        db.session.add(new_q)
        db.session.commit()

    return redirect('/')

@app.route('/my_questions')
def my_questions():
    if 'user_id' not in session:
        return redirect('/login')

    user = User.query.get(session['user_id'])
    return render_template('my_questions.html', questions=user.questions)

@app.route('/answer/<int:question_id>', methods=['POST'])
def answer_question(question_id):
    if 'user_id' not in session:
        return redirect('/login')

    text = request.form['answer']
    user_id = session['user_id']

    new_answer = Answer(text=text, question_id=question_id, user_id=user_id)
    db.session.add(new_answer)
    db.session.commit()

    return redirect('/')

@app.route('/logout')
def logout(): 
    session.pop('user_id', None)
    return redirect('/login')

@app.route('/test_users')
def test_users():
    users = User.query.all()
    return "<br>".join([user.username for user in users])

if __name__ == '__main__':
    app.run(debug=True)