from flask import Flask, render_template, request, redirect, session
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, Question, Answer
import os

app = Flask(__name__)
app.secret_key = 'clave_secreta'

basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'db.sqlite3')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect('/login')
    user = User.query.get(session['user_id'])
    questions = Question.query.order_by(Question.id.desc()).all()
    return render_template('questions.html', questions=questions, is_admin=user.is_admin)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])

        if User.query.filter_by(username=username).first():
            return render_template('register.html', error='Usuario ya existe')

        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect('/login')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            return redirect('/')
        return render_template('login.html', error='Credenciales incorrectas')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

@app.route('/add_question', methods=['POST'])
def add_question():
    if 'user_id' not in session:
        return redirect('/login')
    text = request.form['text']
    if text:
        question = Question(text=text, user_id=session['user_id'])
        db.session.add(question)
        db.session.commit()
    return redirect('/')

@app.route('/answer/<int:question_id>', methods=['POST'])
def answer_question(question_id):
    if 'user_id' not in session:
        return redirect('/login')
    text = request.form['answer']
    if text:
        answer = Answer(text=text, question_id=question_id, user_id=session['user_id'])
        db.session.add(answer)
        db.session.commit()
    return redirect('/')

@app.route('/my_questions')
def my_questions():
    if 'user_id' not in session:
        return redirect('/login')
    user = User.query.get(session['user_id'])
    questions = Question.query.filter_by(user_id=user.id).all()
    return render_template('questions.html', questions=questions, is_admin=user.is_admin)

@app.route('/delete_answer/<int:id>', methods=['POST'])
def delete_answer(id):
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return "Acceso denegado"
    answer = Answer.query.get_or_404(id)
    db.session.delete(answer)
    db.session.commit()
    return redirect('/')

@app.route('/delete_question/<int:id>', methods=['POST'])
def delete_question(id):
    user = User.query.get(session['user_id'])
    if not user.is_admin:
        return "Acceso denegado"
    question = Question.query.get_or_404(id)
    db.session.delete(question)
    db.session.commit()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)